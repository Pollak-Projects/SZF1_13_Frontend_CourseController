<template>
  <div class="flex items-center justify-center min-h-screen">
    <div class="flex flex-col gap-[10vh] sm:gap-[15vh] md:gap-[20vh]">
      <div class="flex flex-col items-center justify-center backdrop-blur-md shadow-figmaxl py-[3vh] sm:py-[4vh] md:py-[5vh] rounded-3xl">
        <div class="flex flex-col gap-[3vh] sm:gap-[4vh] md:gap-[5vh] mb-[5vh]">
          <p class="place-self-center text-lg sm:text-xl md:text-4xl">Bejegyzések</p>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-y-[3vh] gap-x-[5vw]">
            <section class="entries">

              <table class="entry-table w-full">
                <thead>
                  <tr>
                    <th class="text-center">Cím</th>
                    <th class="text-center">Műveletek</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="(entry, index) in entries" :key="index">
                    <td>{{ entry }}</td>
                    <td>
                      <button @click="editEntry(entry)" class="text-blue-500 hover:text-blue-700">✏️</button>
                      <button @click="deleteEntry(index)" class="text-red-500 hover:text-red-700">🗑️</button>
                    </td>
                  </tr>
                  <tr>
                    <td colspan="2" class="text-center">
                      <button @click="addNewEntry" class="bg-purple-500 text-white rounded-lg py-2 px-4 hover:bg-purple-600">Új bejegyzés</button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </section>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      entries: ['HTML alapok', 'CSS alapok', 'JS alapok'],
    };
  },
  methods: {
    editEntry(entry) {
      alert(`Editing entry: ${entry}`);
    },
    deleteEntry(index) {
      this.entries.splice(index, 1);
    },
    addNewEntry() {
      const newEntry = prompt("Add new entry title:");
      if (newEntry) {
        this.entries.push(newEntry);
      }
    },
  },
};
</script>

<style scoped>

.min-h-screen {
  height: 10px;
  width: -100px;

}
</style>
